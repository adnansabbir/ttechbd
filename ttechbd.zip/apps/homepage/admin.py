from django.contrib import admin
from . import models

admin.site.register(models.Company)
admin.site.register(models.Address)
admin.site.register(models.SliderImages)
admin.site.register(models.WhatWeDoSection)
admin.site.register(models.WhatWeDoCards)
admin.site.register(models.WhyChooseUsSection)
admin.site.register(models.WhyChooseUsCards)
admin.site.register(models.FlatIconsClassName)
admin.site.register(models.RecentProjects)
admin.site.register(models.Footer)
admin.site.register(models.FooterLink)
