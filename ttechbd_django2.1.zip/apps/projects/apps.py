from django.apps import AppConfig


class ProjectsConfig(AppConfig):
    name = 'apps.projects'
